﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackPropagationXOR
{
    class Train
    {
        public static void train()
        {
            // the input values
            double[,] inputs =
            {
                { 0, 0},
                { 0, 1},
                { 1, 0},
                { 1, 1}
            };

            // desired results
            double[] results = { 0, 1, 1, 0 };

            // creating the neurons
            Neuron hiddenNeuron1 = new Neuron();
            Neuron hiddenNeuron2 = new Neuron();
            Neuron outputNeuron = new Neuron();

            // random weights
            hiddenNeuron1.RandomizeWeights();
            hiddenNeuron2.RandomizeWeights();
            outputNeuron.RandomizeWeights();

            int epoch = 0;

        Retry:
            epoch++;
            for (int i = 0; i < 4; i++)  // very important, do NOT train for only one example
            {
                // 1) forward propagation (calculates output)
                hiddenNeuron1.inputs = new double[] { inputs[i, 0], inputs[i, 1] };
                hiddenNeuron2.inputs = new double[] { inputs[i, 0], inputs[i, 1] };

                outputNeuron.inputs = new double[] { hiddenNeuron1.Output, hiddenNeuron2.Output };


                Console.WriteLine("{0} xor {1} = {2}", inputs[i, 0], inputs[i, 1], outputNeuron.Output);

                if (i==3)
                    Console.WriteLine("---- :-) ----");

                // 2) back propagation (adjusts weights)

                // adjusts the weight of the output neuron, based on it's error
                outputNeuron.error = sigmoid.Derivative(outputNeuron.Output) * (results[i] - outputNeuron.Output);
                outputNeuron.AdjustWeights();

                // then adjusts the hidden neurons' weights, based on their errors
                hiddenNeuron1.error = sigmoid.Derivative(hiddenNeuron1.Output) * outputNeuron.error * outputNeuron.weights[0];
                hiddenNeuron2.error = sigmoid.Derivative(hiddenNeuron2.Output) * outputNeuron.error * outputNeuron.weights[1];

                hiddenNeuron1.AdjustWeights();
                hiddenNeuron2.AdjustWeights();
            }

            // Continue training for 2000 epochs
            if (epoch < 2000)
            {
                Console.WriteLine("Epoch : " + epoch);
                goto Retry;
            }
        }
    }
}
